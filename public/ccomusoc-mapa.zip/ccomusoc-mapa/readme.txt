=== CComuSoc - Mapa Interactivo ===
Contributors: ccomusoc
Tags: mapa, comunicacion, desarrollo, geolocalizacion, testimonios
Requires at least: 5.6
Tested up to: 6.7
Stable tag: 2.4.0
License: GPLv3 or later

Incrusta y sincroniza el Mapa Interactivo Territorial de Comunicación para el Desarrollo en ccomusoc.com.ar.
